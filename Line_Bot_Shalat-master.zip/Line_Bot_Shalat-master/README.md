# Line_Bot_Shalat
Script Webhook Line Messaging API Use Heroku Or Other

Updated V1.2 : Response a Bit Faster

# Developer:
Copyright @ Medantechno.com

Modified @ Farzain - zFz

# Deploy to:
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

# Source:
Source : https://medantechno.com/read/news/23/tutorial-membuat-bot-messaging-api-line

PHP Unirest Script Included
